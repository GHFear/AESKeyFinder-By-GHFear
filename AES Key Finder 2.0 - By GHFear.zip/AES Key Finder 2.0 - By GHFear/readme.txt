.::::::::AES Key Finder 2.0::::::::.

By downloading and using this tool you agree that this tool is for research purposes only and that I (GHFear) am not responsible for what (you) the end user does with it.

Step 1.

Drop your games largest executable (usually called "Gamename"-Shipping.exe) into this 
folder.

------------------------------------------------------------------------------------------
Step 2.
Run "Find_AES_Key.bat" on Windows or "Find_AES_Key_Linux.sh" on Linux (with Wine installed):

This batch file will run a series of scripts through QuickBMS and find any Unreal Engine 4.19 -> 5.3 format,
256-bit AES Keys.

------------------------------------------------------------------------------------------



/GHFear
